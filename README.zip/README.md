# SQL Server Docker Manager

Desktop app em Python/PySide6 para gerir backups e restores de bases SQL Server em Docker.

## Funcionalidades

- Listar backups `.bak`
- Restaurar backups
- Fazer backup de bases existentes
- Listar bases SQL Server
- Configurações locais
- Tema dark/light
- Logs em tempo real

## Requisitos

- Python 3.10+
- Docker instalado
- Container SQL Server em execução
- `sqlcmd` dentro do container

## Instalação

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python main.py