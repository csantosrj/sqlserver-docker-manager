# Build Guide

Este documento explica como gerar pacotes executáveis do **SQL Server Docker Manager** para Linux, Windows e macOS.

A aplicação foi criada em Python com PySide6 e deve ser empacotada com PyInstaller.

## Regra importante

O PyInstaller não gera builds universais para todos os sistemas a partir de uma única máquina.

Cada build deve ser gerado no próprio sistema operacional:

| Sistema alvo | Onde gerar o build |
| ------------ | ------------------ |
| Linux        | Linux ou WSL       |
| Windows      | Windows            |
| macOS        | macOS              |

Exemplo:

```text
Build para Windows -> gerar no Windows
Build para Linux   -> gerar no Linux/WSL
Build para macOS   -> gerar no macOS
```

## Estrutura esperada do projeto

```text
sqlserver-docker-manager/
├── main.py
├── requirements.txt
├── README.md
├── BUILD.md
├── MANUAL.md
├── assets/
│   ├── app_icon.png
│   └── app_icon.ico
├── ui/
│   ├── main_window.py
│   ├── styles.py
│   └── components/
├── services/
│   └── docker_sqlserver.py
└── workers/
    ├── restore_worker.py
    └── backup_worker.py
```

## Requisitos

Antes de gerar o build, confirma que tens:

* Python 3.10 ou superior;
* Docker instalado;
* PyInstaller instalado;
* dependências do projeto instaladas;
* pasta `assets/` com os ícones da aplicação.

## Preparar ambiente

Linux/macOS:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pip install pyinstaller
```

Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
pip install pyinstaller
```

## Build para Linux

Executar dentro da pasta do projeto:

```bash
pyinstaller \
  --noconfirm \
  --clean \
  --onedir \
  --windowed \
  --name SQLServerDockerManager \
  --add-data "assets:assets" \
  --icon assets/app_icon.png \
  main.py
```

O resultado será criado em:

```text
dist/SQLServerDockerManager/
```

Para executar:

```bash
./dist/SQLServerDockerManager/SQLServerDockerManager
```

Para distribuir:

```bash
cd dist
tar -czf SQLServerDockerManager-linux.tar.gz SQLServerDockerManager
```

## Build para Windows

Executar no Windows PowerShell:

```powershell
pyinstaller `
  --noconfirm `
  --clean `
  --onedir `
  --windowed `
  --name SQLServerDockerManager `
  --add-data "assets;assets" `
  --icon assets/app_icon.ico `
  main.py
```

O resultado será criado em:

```text
dist/SQLServerDockerManager/
```

O executável principal será:

```text
dist/SQLServerDockerManager/SQLServerDockerManager.exe
```

Para distribuir, compactar a pasta:

```text
dist/SQLServerDockerManager/
```

em um ficheiro `.zip`.

## Build para macOS

Executar no macOS:

```bash
pyinstaller \
  --noconfirm \
  --clean \
  --onedir \
  --windowed \
  --name SQLServerDockerManager \
  --add-data "assets:assets" \
  --icon assets/app_icon.icns \
  main.py
```

Observação: para macOS, o ideal é usar um ícone `.icns`.

O resultado normalmente será criado em:

```text
dist/SQLServerDockerManager.app
```

Para distribuir no macOS, o ideal é gerar um `.dmg` posteriormente.

## Modo onedir vs onefile

Recomendado para este projeto:

```text
--onedir
```

Motivo:

* mais estável com PySide6;
* mais fácil de debugar;
* arranque mais rápido;
* menos problemas com assets e bibliotecas Qt.

Evitar inicialmente:

```text
--onefile
```

O modo `onefile` pode ser usado futuramente, mas pode criar problemas com ficheiros temporários, assets e tempo de arranque.

## Docker não é incluído no pacote

O executável da aplicação não instala Docker nem SQL Server.

A máquina onde a aplicação for usada precisa ter:

* Docker instalado;
* container SQL Server em execução;
* permissão para executar comandos `docker`;
* `sqlcmd` instalado dentro do container SQL Server.

## Teste após build

Depois de gerar o pacote, testar:

1. abrir a aplicação;
2. ir em Settings;
3. configurar container, utilizador e password;
4. clicar em Testar conexão;
5. abrir Databases;
6. atualizar lista de bases;
7. testar backup;
8. testar restore com uma base de teste.

## Limpeza de builds antigos

Para limpar builds anteriores:

Linux/macOS:

```bash
rm -rf build dist *.spec
```

Windows PowerShell:

```powershell
Remove-Item -Recurse -Force build, dist
Remove-Item *.spec
```

## Versão inicial recomendada

Para uma primeira release:

```text
v0.1.0
```

Sugestão de artefactos:

```text
SQLServerDockerManager-v0.1.0-linux.tar.gz
SQLServerDockerManager-v0.1.0-windows.zip
SQLServerDockerManager-v0.1.0-macos.dmg
```
