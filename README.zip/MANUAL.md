# Manual de Utilização

Este manual explica como usar o **SQL Server Docker Manager**.

A ferramenta permite gerir backups e restores de bases SQL Server que estão a correr dentro de containers Docker.

## Objetivo da ferramenta

Com esta aplicação é possível:

* listar containers SQL Server disponíveis;
* configurar ligação ao SQL Server;
* listar bases de dados;
* criar backups `.bak`;
* restaurar backups `.bak`;
* acompanhar logs em tempo real;
* validar operações de backup e restore.

## Requisitos

Antes de usar a aplicação, confirma que tens:

* Docker instalado;
* container SQL Server em execução;
* password do utilizador SQL;
* pasta de backups dentro do container;
* `sqlcmd` disponível dentro do container.

Por padrão, a ferramenta assume:

```text
Container: okapa-sqlserver
Backup dir: /var/opt/mssql/backup
Data dir: /var/opt/mssql/data
```

## Abrir a aplicação

Em modo desenvolvimento:

```bash
python main.py
```

Em modo empacotado, executar o ficheiro gerado pelo build:

Linux:

```bash
./SQLServerDockerManager
```

Windows:

```text
SQLServerDockerManager.exe
```

macOS:

```text
SQLServerDockerManager.app
```

## Menu Settings

O menu **Settings** deve ser configurado primeiro.

Aqui defines a ligação padrão usada por todos os outros ecrãs.

### Campos principais

| Campo             | Descrição                                               |
| ----------------- | ------------------------------------------------------- |
| Container padrão  | Nome do container SQL Server                            |
| Utilizador padrão | Utilizador SQL Server                                   |
| Password          | Password do utilizador SQL                              |
| Diretório backup  | Pasta onde ficam os `.bak` dentro do container          |
| Diretório dados   | Pasta onde ficam os `.mdf` e `.ldf` dentro do container |

Exemplo:

```text
Container padrão: okapa-sqlserver
Utilizador padrão: sa
Diretório backup: /var/opt/mssql/backup
Diretório dados: /var/opt/mssql/data
```

### Password

A password fica escondida por padrão.

Usa o botão:

```text
Mostrar
```

para ver temporariamente.

Usa:

```text
Limpar
```

para remover a password da sessão.

### Guardar password

Existe a opção:

```text
Guardar password neste computador por minha conta e risco
```

Se esta opção estiver desligada, a password fica apenas na memória enquanto a aplicação está aberta.

Se esta opção estiver ligada, a password será guardada localmente nas configurações do utilizador.

Atenção: isto é prático, mas não substitui um cofre seguro de passwords.

### Testar conexão

Depois de preencher os dados, clicar em:

```text
Testar conexão
```

A ferramenta irá validar se consegue ligar ao SQL Server usando o container, utilizador e password configurados.

## Menu Databases

O menu **Databases** mostra as bases disponíveis no SQL Server.

Para usar:

1. configurar ligação no menu Settings;
2. abrir o menu Databases;
3. clicar em Atualizar lista de bases.

A tabela mostra informações como:

* nome da base;
* estado;
* recovery model;
* collation;
* compatibility level;
* tamanho em MB.

Este ecrã é útil para confirmar que a ligação está correta antes de fazer backup ou restore.

## Menu Backup

O menu **Backup** permite criar um ficheiro `.bak` de uma base existente.

### Passos

1. configurar ligação no menu Settings;
2. abrir o menu Backup;
3. clicar em Atualizar bases;
4. escolher a base origem;
5. gerar ou escrever o nome do ficheiro `.bak`;
6. clicar em Fazer backup;
7. acompanhar os logs.

O backup será criado no diretório configurado, normalmente:

```text
/var/opt/mssql/backup
```

### Nome automático

O botão:

```text
Gerar nome
```

cria automaticamente um nome baseado no padrão configurado em Settings.

Exemplo:

```text
MinhaBase_20260629_153000.bak
```

### Validação

Se a opção estiver ativa, a ferramenta executa:

```sql
RESTORE VERIFYONLY
```

depois do backup.

Isto ajuda a confirmar que o ficheiro `.bak` foi criado corretamente.

## Menu Restore

O menu **Restore** permite restaurar um ficheiro `.bak`.

### Passos

1. configurar ligação no menu Settings;
2. garantir que o `.bak` está dentro da pasta de backups do container;
3. abrir o menu Restore;
4. clicar em Atualizar backups;
5. escolher o ficheiro `.bak`;
6. informar o nome da base destino;
7. clicar em Restaurar backup;
8. acompanhar os logs.

### Pasta esperada dos backups

Por padrão:

```text
/var/opt/mssql/backup
```

### Pasta esperada dos dados

Por padrão:

```text
/var/opt/mssql/data
```

Durante o restore, a ferramenta identifica os logical names com:

```sql
RESTORE FILELISTONLY
```

Depois monta o restore usando:

```sql
RESTORE DATABASE
```

com `MOVE` para os ficheiros `.mdf` e `.ldf`.

### Restaurar com outro nome

Para testar com segurança, recomenda-se restaurar usando outro nome.

Exemplo:

```text
Backup: Kora_Demo_Distr.bak
Base destino: Kora_Demo_Distr_Restored
```

Assim não sobrescreves a base original.

### Sobrescrever base existente

Se a base destino já existir, a ferramenta deve pedir confirmação antes de restaurar por cima.

Isto evita acidentes.

## Logs

A área de logs mostra:

* passos da operação;
* mensagens amigáveis;
* progresso do SQL Server;
* erros técnicos completos.

O botão:

```text
Copiar log
```

copia todo o log para a área de transferência.

Isto é útil para debug.

## Fluxo recomendado de teste

Antes de usar numa base real, cria uma base pequena de teste.

Exemplo:

```sql
CREATE DATABASE TesteRestore;
GO

USE TesteRestore;
GO

CREATE TABLE Clientes (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Nome NVARCHAR(100) NOT NULL
);
GO

INSERT INTO Clientes (Nome)
VALUES ('Claudio'), ('Marcelo'), ('Joao');
GO
```

Depois:

1. fazer backup da base `TesteRestore`;
2. restaurar como `TesteRestore_Restored`;
3. validar se a tabela e os dados existem.

## Erros comuns

### Docker não encontrado

Verifica se o Docker está instalado e ativo.

```bash
docker ps
```

### Container não encontrado

Confirma o nome do container:

```bash
docker ps --format "{{.Names}}"
```

Depois ajusta o nome no menu Settings.

### Password inválida

Confirma o utilizador e a password no menu Settings.

Depois clica em Testar conexão.

### sqlcmd não encontrado

A ferramenta espera que o `sqlcmd` exista dentro do container.

Caminhos comuns:

```text
/opt/mssql-tools18/bin/sqlcmd
/opt/mssql-tools/bin/sqlcmd
```

### Backup não aparece

Confirma se o ficheiro `.bak` está dentro do container:

```bash
docker exec -it okapa-sqlserver bash -lc "ls -lh /var/opt/mssql/backup"
```

### Sem permissão para Docker no Linux

Confirma se o utilizador consegue executar:

```bash
docker ps
```

Se não conseguir, pode ser necessário adicionar o utilizador ao grupo `docker`.

## Segurança

A ferramenta executa comandos de backup e restore em bases SQL Server.

Usa com cuidado, especialmente em ambientes de produção.

Recomendações:

* testar primeiro em bases pequenas;
* evitar restaurar por cima de bases reais sem confirmação;
* não guardar password se estiver num computador partilhado;
* manter backups importantes fora do container;
* copiar logs em caso de erro.

## Encerrar aplicação

Para sair, usar o botão:

```text
Sair
```

no menu lateral.
